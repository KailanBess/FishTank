FishTank Debian server deployment kit

Extract the whole archive. Read server/README.md and docs/SERVER-EXPANSION.md.
Only example configuration is included. Supply real secrets locally.
Review server/install-debian.sh before running as root. It installs initial files only; it does not start/expose the service or replace an existing deployment.
SMS needs a modem/SIM or configured gateway; mail needs configured delivery.
