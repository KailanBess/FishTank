# Dashboard, scheduling and support tools

Dashboard shows a maximum of three attention items, with an action for each, and a read-only protection refresh. Protection health is assessed separately from scans. “Protected” requires all seven named Windows protection checks to report no issue within 15 minutes. Missing, partial, conflicting, future-dated or stale results show “Couldn’t check”; current review findings show “Needs attention”. Another antivirus or organizational policy can affect these readings.

Antivirus → Configure scan schedule offers opt-in quick/full scans, daily or weekly, at a local time. Schedules are encrypted for this Windows profile, start disabled, and run only while FishTank is open, including tray mode. Missed occurrences catch up once; dialogs and foreground FishTank work defer scans. The next occurrence is persisted before launching, preventing replay after restart. A failed occurrence is retained as a failure, and the next attempt follows the configured interval. Closing during a scan may leave Defender working without a completion record. Existing Defender policy controls remediation. No Windows scheduled task, service, elevation or protection-policy changes are created.

Settings → Folder backup reminders lets you add up to 50 important folders with a 1–365-day interval. “Record backup made now” records your own declaration after using a separate backup tool; FishTank neither copies nor verifies those folders. Never-recorded, overdue and future-dated copies need attention. In-app notices use the existing opt-in reminders and backup-age warning preferences. Paths and dates are encrypted locally.

Activity timeline combines recent scan/quarantine audit events, observed live detections, retained backup events and new update/scheduling events, newest first. Search or filter by category. It retains at most 1,000 displayed entries from the latest 14 daily audit files (up to 2 MiB each), retained backup/detection history and 500 encrypted app events. Coverage gaps are explicit. Update checks/staging are distinguished from installation; consult the separate installer result after restart. Monitoring cannot reconstruct detections while it was off. Raw paths and command payloads are omitted from this view.

Settings → Search settings finds appearance, app access/MFA, scheduling, reminders, backups, updates, folder integrity, protection health, browser access, monitoring, activity and support controls. Matching uses all typed words, without contacting a service.

Preview support report is available from Dashboard and Settings. It collects selected version/status/count summaries, excluding raw paths, credentials, account names, vault contents and command output. The preview is editable; saving writes exactly its current text to a local `.txt` file. Review it before sharing. Nothing is sent automatically.

Validation includes schedule catch-up/replay/DST checks, conservative protection classification, encrypted folder reminder persistence, timeline categories/order/coverage and support-report privacy checks, plus narrow-window dialog screenshots and the existing Windows UI suite. Automated tests do not launch real scheduled malware scans or perform real backup copies.

## Window frame and mascot (0.15.1)

In Customize → Appearance, Outside window / title bar offers two mutually exclusive choices: **Follow Windows** (default) and **Custom color**. Follow Windows resets custom overrides and follows the PC's light/dark and title-bar accent settings. Custom color enables a color picker for the native title bar and border, with automatic contrasting title text. This preference is independent of the app's theme and accent, participates in preview, Save, Cancel, Revert, Defaults and appearance import/export, and applies to FishTank's native app/dialog frames. New app dialogs inherit the FishTank icon, including the selected app-icon color; open dialogs update during preview. Windows High Contrast takes precedence. Custom frame colors require Windows 11; unsupported Windows versions retain their system frame. Native window controls and resizing remain available. See [Microsoft's frame attributes](https://learn.microsoft.com/en-us/windows/win32/api/dwmapi/ne-dwmapi-dwmwindowattribute).

Clicking the mascot now produces 3–6 bubbles of radius 2.5–5 pixels, with a wider initial horizontal velocity that eases as they float upward. The overlay retains a maximum of 40 bubbles and continues to the screen top. Reduced motion still disables the effect.

## Appearance repaint fixes (0.15.2)

The 38-second recording was reviewed at half-second intervals. Around 19–25 seconds, appearance preview shows stale text, blank blocks and mismatched colors while the main window rebuilds behind its modal dialog. The fix batches native redraw, restores layout in a finally block, repaints all children and the frame, and explicitly reattaches the explanation bar before completing the rebuild. Rapid appearance changes coalesce for 120 ms. Reused fonts avoid accumulating new font resources on every preview.

Explanation controls now use the app palette. Customize's controls, tab strip and choice lists track the preview palette instead of mixing default bright controls with a dark body. The footer displays the assembly version rather than a fixed old version. Native OS scrollbars and common file/color dialogs retain Windows behavior.

Windows UI checks exercise eight successive theme/font/text-size changes with Customize open, verify latest-preview completion and modal ownership, compare inherited icon pixels, confirm exclusive frame choices, and verify Cancel restores app/frame state without saving. Four main-window preview captures and a Customize capture are included in the CI screenshot artifact. Automated render checks do not establish identical GPU/Game Bar capture behavior on every PC.

## Barrel direction and GitHub updates (0.15.3)

Mascot bubbles start at the barrel opening within the displayed image rectangle, including Zoom letterboxing and padding. Each bubble launches rightward along the barrel, then curves upward; randomness varies speed/size without choosing a backward direction. Counts, visibility, reduced-motion behavior and the screen-wide overlay remain bounded as before.

Open **Settings → GitHub updates** (also searchable in All tools). The dedicated screen shows the installed version, channel, publisher-trust readiness and staged version. **Check GitHub release** contacts GitHub only after being clicked; **Download and verify** stages both executables; **Apply update** separately confirms replacement/restart and repeats digest, signature, publisher and newer-version checks. Applying is disabled without a complete staged update and configured publisher trust. Publisher trust settings, release channel, the release page and previous installation result are available on the same screen.

Source commits and preview ZIPs are not published releases. At validation time the public repository had no releases. Unsigned preview executables cannot pass the trusted-update gate; use the downloadable ZIP until signed releases and publisher trust are configured. No existing update verification was relaxed.

## Easy preview updates (0.15.4)

Settings → GitHub updates → Use preview updates offers certificate-free prerelease updates after one explicit opt-in. New versions publish automatically after required CI checks pass. GitHub identities/digests, newer-version rules, staging isolation, pre-apply rechecks and rollback remain required. Signed releases still require publisher trust. See PREVIEW-UPDATES.md; this supersedes the signed-only limitation described for 0.15.3 above.
