FishTank unsigned development preview

Version 0.13.0 adds backup failure alerts, vault health, recorded security changes, cleanup previews, portable profile transfer, isolated --demo mode, in-app notes and a guided server connection wizard. Read EVERYDAY-TOOLS.md. It retains Ctrl+K search/favorites, scan queues, encrypted backups, vault history/attachments/import/undo, notifications, profiles, signed health reports and optional server passkeys/status. Read APP-EXPANSION.md and SERVER-EXPANSION.md. The server is prepared but NOT DEPLOYED. It retains first-run setup, scan progress and cancellation evidence, actionable alerts, recovery center, accessibility improvements and signed-release preparation.
It also includes the dashboard, scan scheduling, activity timeline and folder backup reminders,
clear protection status, settings search, and editable support-report export.
See APP-INSIGHTS.md for controls, defaults, and behavior.

Extract into a NEW folder. Requires Windows 10/11 and .NET Framework 4.8.
For an isolated profile, run FishTank.exe --portable.
Normal mode uses the existing Windows FishTank profile.
Automatic scans and notification reminders are opt-in. Folder reminders do not copy files.
This unsigned preview cannot pass the app's signed-update gate.
No private configuration, credentials, databases, or test fixtures are packaged.
