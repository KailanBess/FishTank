FishTank 0.7.0.0 unsigned development preview

Requires Windows 10/11 and .NET Framework 4.8. Extract all files into a NEW folder.
For isolated testing, run: FishTank.exe --portable
Portable mode uses a data folder beside the executable. Normal mode uses your existing Windows FishTank profile; back it up privately before testing.

Security Center > Security and integrity tools contains protection reviews, startup and folder integrity, permission/network reviews, backup verification and isolated restore drills, locking/reminder preferences, publisher checks and verified-update staging.
Simple view is the default. Advanced view adds evidence and controls without changing protection.

This is not an audited or production-approved security release. Windows runtime and visual validation remain pending in the Linux build workspace; see SECURITY-AND-INTEGRITY.md for the exact checks and limits.
The executables are unsigned and intentionally cannot pass the signed-update gate. No automatic update installer is included. A publisher certificate, signed releases and an independent security audit remain external requirements.

No private configuration, passwords, device tokens or databases are included.
