FishTank 0.6.1 unsigned development preview

Requires Windows 10/11 and .NET Framework 4.8. Extract all files into a new folder. Run FishTank.exe. Do not run as administrator unless a selected Windows operation needs it.

Windows execution, screenshots and real MFA delivery have not been validated in the Linux build workspace. Read UI-REVIEW.md. This is not an audited or production-approved security tool. Preserve private backups before testing with existing app data. Normal mode uses your existing Windows FishTank data profile; --portable uses a data folder beside the executable for isolated UI testing.

Switch Simple/Advanced views from Dashboard or Settings. The SHA-256 tool is in Security Center. Original uploaded executables remain under windows/ in the repository.
