FishTank unsigned development preview

Version 0.15.3 adds forward muzzle bubbles and Settings > GitHub updates with release checking, download verification and Apply update. A published signed release and publisher trust are still required for applying updates. Version 0.15.2 fixed appearance preview repaint artifacts, font allocation, themed explanation controls and Customize rendering. Version 0.15.1 added separate Follow Windows and Custom color frame choices in Customize, plus smaller/fewer bubbles with a wider burst. Custom native frame colors require Windows 11; Windows 10 retains its native frame. Version 0.15.0 improved live Defender checking with durable event checkpoints, available-record recovery, verified log health, fresh race-safe status checks, source timestamps, accurate notice severity and explicit retention limits. Read LIVE-DETECTION.md. Version 0.14.0 added ransomware and audit-first ASR/CFA controls, app/hardware security reviews, software update inventory, opt-in persistence/network monitoring and incident-response cases. Read SECURITY-COVERAGE.md. It retains the previous vault, backup, demo, server wizard and workspace tools.
It also includes the dashboard, scan scheduling, activity timeline and folder backup reminders,
clear protection status, settings search, and editable support-report export.
See APP-INSIGHTS.md for controls, defaults, and behavior.

Extract into a NEW folder. Requires Windows 10/11 and .NET Framework 4.8.
For an isolated profile, run FishTank.exe --portable.
Normal mode uses the existing Windows FishTank profile.
Automatic scans and notification reminders are opt-in. Folder reminders do not copy files.
This unsigned preview cannot pass the app's signed-update gate.
No private configuration, credentials, databases, or test fixtures are packaged.
