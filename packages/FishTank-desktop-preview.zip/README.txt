FishTank 0.8.1.0 unsigned development preview

Requires Windows 10/11 and .NET Framework 4.8. Extract all files into a NEW folder.
For isolated testing, run: FishTank.exe --portable
Portable mode uses a data folder beside the executable. Normal mode uses your existing Windows FishTank profile; back it up privately before testing.

Protected Files adds independent passphrase-encrypted containers for selected files and folders. Read PROTECTED-FILES-AND-GITHUB-UPDATES.md before moving originals or exporting plaintext.

Security Center > Security and integrity tools contains protection reviews, startup and folder integrity, permission/network reviews, backup verification and isolated restore drills, locking/reminder preferences, publisher checks and verified-update staging.
Disk health and free space adds read-only device/capacity warnings; Backup and recovery shows recorded copy age separately from verification age. Read DISK-HEALTH-AND-BACKUP-AGE.md for thresholds, defaults and unknown-data limits.
Simple view is the default. Advanced view adds evidence and controls without changing protection.

This is not an audited or production-approved security release. Windows runtime and visual validation remain pending in the Linux build workspace; see SECURITY-AND-INTEGRITY.md for the exact checks and limits.
The executables are unsigned and intentionally cannot pass the signed-update gate. GitHub updates have a separate confirmed installer; only signed, pinned, newer releases can be installed. A publisher certificate, GitHub release secrets, signed assets and an independent security audit remain external requirements.

No private configuration, passwords, device tokens or databases are included.
