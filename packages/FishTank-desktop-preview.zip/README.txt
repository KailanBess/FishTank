FishTank unsigned development preview

Updated dashboard, scan scheduling, combined activity timeline, important-folder backup reminders,
clear protection status, settings search, and editable support-report export.
See APP-INSIGHTS.md for controls, defaults, and behavior.

Extract into a NEW folder. Requires Windows 10/11 and .NET Framework 4.8.
For an isolated profile, run FishTank.exe --portable.
Normal mode uses the existing Windows FishTank profile.
Automatic scans and notification reminders are opt-in. Folder reminders do not copy files.
This unsigned preview cannot pass the app's signed-update gate.
No private configuration, credentials, databases, or test fixtures are packaged.
